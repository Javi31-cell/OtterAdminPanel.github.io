#!/usr/bin/env python3
"""
servidor_otter.py: servicio de Otter Studio (panel de administración + API de jugadores). Solo librería estándar.

  python servidor_otter.py asistente                                      (crea administradores y te da su clave MFA)
  python servidor_otter.py crear-admin --usuario javi --rol Propietario   (uno solo; también muestra la clave MFA)
  python servidor_otter.py mfa --usuario javi                             (vuelve a mostrar la clave MFA y el código actual)
  python servidor_otter.py ejecutar                                       (http://127.0.0.1:8750)
  python servidor_otter.py cerrar-sesiones --usuario javi                 (revoca todas sus sesiones)

Seguridad aplicada: contraseñas con scrypt, MFA TOTP obligatorio, sesiones en cookie HttpOnly+SameSite=Strict
(guardadas con hash, caducan y se revocan), bloqueo por intentos, permisos por rol comprobados en CADA petición,
cabecera anti-CSRF, auditoría de acciones, descargas solo con permiso y rutas cerradas a una lista blanca.
Por defecto escucha SOLO en 127.0.0.1: para usarlo desde Internet ponlo detrás de HTTPS (Caddy/Nginx) y, mejor,
detrás de una VPN o un proxy de identidad. Con HTTPS añade --https para marcar la cookie como Secure.

Datos (servidor_datos/): otter.db, claves/ (la privada firma las actualizaciones), contenido/<id>/ (lo que se publica),
publicado/<id>/ (lo que descargan los jugadores). Haz copia de seguridad de esa carpeta.
"""
import argparse
import base64
import contextlib
import getpass
import hashlib
import hmac
import html
import io
import json
import os
import re
import secrets
import sqlite3
import struct
import sys
import threading
import time
import urllib.parse
import zlib
from datetime import date, datetime
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import publicar as PUB  # noqa: E402

DATOS = os.environ.get("OTTER_DATOS", os.path.join(BASE, "servidor_datos"))
CFG = {"https": False, "url": "", "publico": False}
ROLES = {"Propietario": "*", "Administrador": {"codigo", "revocar", "publicar", "cola", "usuario"},
         "Desarrollador": {"publicar"}, "Moderador": {"usuario"}}
SESION_SEG = 8 * 3600
LIM, LIM_LOCK = {}, threading.Lock()
SEMILLAS = [("world_of_clan_remake", "World Of Clan Remake", "Forge 1.20.1", "disponible",
             "El proyecto de Otter Studio: explora, construye y compite con tu clan."),
            ("proximamente", "Coming Soon", "Forge 1.20.1", "proximamente", "Un nuevo proyecto está en camino.")]
ESTADOS_OK = ("disponible", "actualizacion", "mantenimiento", "proximamente", "oculto")
RE_USUARIO = re.compile(r"^[A-Za-z0-9_]{3,16}$")
RE_DESCARGA = re.compile(r"^(manifest\.json(\.sig)?|files/[0-9a-f]{2}/[0-9a-f]{64})$")
ALFABETO = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


class ErrorApi(Exception):
    def __init__(self, codigo, mensaje):
        super().__init__(mensaje)
        self.codigo, self.mensaje = codigo, mensaje


# ------------------------------------------------------------------ utilidades
def limitar(clave, maximo, ventana):
    ahora = time.time()
    with LIM_LOCK:
        v = [t for t in LIM.get(clave, []) if ahora - t < ventana]
        ok = len(v) < maximo
        if ok:
            v.append(ahora)
        LIM[clave] = v
        return ok


def hash_pw(clave, sal):
    return hashlib.scrypt(clave.encode("utf-8"), salt=sal, n=2 ** 14, r=8, p=1, dklen=32).hex()


def nueva_clave(clave):
    sal = secrets.token_bytes(16)
    return sal.hex(), hash_pw(clave, sal)


def cfg():
    try:
        with open(os.path.join(DATOS, "config.json"), "r", encoding="utf-8") as f:
            return {"mfa": json.load(f).get("mfa", True) is not False}
    except Exception:
        return {"mfa": True}


def cfg_guardar(mfa):
    with open(os.path.join(DATOS, "config.json"), "w", encoding="utf-8") as f:
        json.dump({"mfa": bool(mfa)}, f)


LOCAL = ("127.0.0.1", "::1")
CAB_PROXY = ("CF-Connecting-IP", "CF-Ray", "X-Forwarded-For", "X-Forwarded-Host", "Forwarded", "X-Real-IP")


def tras_proxy(h):
    """True si la petición llega por un túnel o proxy que corre en este mismo equipo (es decir, desde Internet)."""
    return h.client_address[0] in LOCAL and any(h.headers.get(k) for k in CAB_PROXY)


def mfa_obligatorio(h):
    """El MFA solo puede estar apagado en uso 100 % local. Desde Internet (modo público, túnel o proxy) SIEMPRE se exige,
    aunque alguien lo apague en la configuración mientras el servidor está abierto."""
    return cfg()["mfa"] or bool(CFG.get("publico")) or tras_proxy(h) or h.client_address[0] not in LOCAL


def es_https(h):
    return bool(CFG["https"]) or h.headers.get("X-Forwarded-Proto") == "https"


def sha(t):
    return hashlib.sha256(t.encode()).hexdigest()


def totp(secreto, t=None, paso=30):
    clave = base64.b32decode(secreto + "=" * (-len(secreto) % 8))
    h = hmac.new(clave, struct.pack(">Q", int((t if t is not None else time.time()) // paso)), "sha1").digest()
    o = h[-1] & 15
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 10 ** 6:06d}"


def totp_ok(secreto, codigo):
    return any(hmac.compare_digest(totp(secreto, time.time() + d * 30), codigo) for d in (-1, 0, 1))


def fmt(iso):
    try:
        a, m, d = iso[:10].split("-")
        return f"{d}/{m}/{a}"
    except ValueError:
        return "—"


def db():
    c = sqlite3.connect(os.path.join(DATOS, "otter.db"), timeout=15)
    c.row_factory = sqlite3.Row
    return c


@contextlib.contextmanager
def tx():
    """Transacción: confirma los cambios y cierra la conexión al salir (o deshace si hubo un error)."""
    c = db()
    try:
        yield c
        c.commit()
    except BaseException:
        c.rollback()
        raise
    finally:
        c.close()


def audit(c, quien, accion):
    c.execute("INSERT INTO auditoria(momento,quien,accion) VALUES(?,?,?)", (time.time(), quien, accion))


ESQUEMA = """
CREATE TABLE IF NOT EXISTS admins(usuario TEXT PRIMARY KEY, rol TEXT, sal TEXT, pw_hash TEXT, totp TEXT, activo INT DEFAULT 1, fallos INT DEFAULT 0, bloqueado_hasta REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sesiones(token_hash TEXT PRIMARY KEY, usuario TEXT, expira REAL, revocada INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS instancias(id TEXT PRIMARY KEY, nombre TEXT, mc TEXT, estado TEXT, descripcion TEXT, version TEXT DEFAULT '', fecha TEXT DEFAULT '', notas TEXT DEFAULT '', estado_manual INT DEFAULT 0, mensaje TEXT DEFAULT '', banner_hash TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS codigos(codigo TEXT PRIMARY KEY, instancias TEXT, expira TEXT, max_usos INT, usos INT DEFAULT 0, revocado INT DEFAULT 0, creado_por TEXT, creado REAL);
CREATE TABLE IF NOT EXISTS canjes(codigo TEXT, usuario TEXT, momento REAL, UNIQUE(codigo, usuario));
CREATE TABLE IF NOT EXISTS usuarios(nombre TEXT PRIMARY KEY, creado REAL, estado TEXT DEFAULT 'Activo', sal TEXT, pw_hash TEXT);
CREATE TABLE IF NOT EXISTS permisos(usuario TEXT, instancia TEXT, UNIQUE(usuario, instancia));
CREATE TABLE IF NOT EXISTS tokens(token_hash TEXT PRIMARY KEY, usuario TEXT, revocado INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS recuperaciones(usuario TEXT, codigo_hash TEXT, expira REAL, usado INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS eventos(id INTEGER PRIMARY KEY, nombre TEXT, capacidad INT, abierto INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS cola(evento INT, usuario TEXT, entrada REAL, UNIQUE(evento, usuario));
CREATE TABLE IF NOT EXISTS auditoria(id INTEGER PRIMARY KEY AUTOINCREMENT, momento REAL, quien TEXT, accion TEXT);
"""


def iniciar():
    for d in ("contenido", "publicado", "claves"):
        os.makedirs(os.path.join(DATOS, d), exist_ok=True)
    with tx() as c:
        c.executescript(ESQUEMA)
        for col in ("estado_manual INT DEFAULT 0", "mensaje TEXT DEFAULT ''", "banner_hash TEXT DEFAULT ''"):          # bases de datos antiguas
            with contextlib.suppress(sqlite3.OperationalError):
                c.execute(f"ALTER TABLE instancias ADD COLUMN {col}")
        for id_, nombre, mc, est, desc in SEMILLAS:                                      # las instancias que ya están en el launcher
            c.execute("INSERT OR IGNORE INTO instancias(id,nombre,mc,estado,descripcion) VALUES(?,?,?,?,?)", (id_, nombre, mc, est, desc))
        os.makedirs(os.path.join(DATOS, "contenido", "world_of_clan_remake"), exist_ok=True)
        if not c.execute("SELECT 1 FROM eventos").fetchone():
            c.execute("INSERT INTO eventos(id,nombre,capacidad) VALUES(1,'Evento de apertura',120)")
    if not os.path.exists(os.path.join(DATOS, "claves", "privada.key")):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                PUB.cmd_claves(SimpleNamespace(carpeta=os.path.join(DATOS, "claves")))
        except ImportError:
            sys.exit("\nFalta la librería 'cryptography' (firma las actualizaciones).\n"
                     "Instálala con este comando y vuelve a intentarlo:\n\n    python -m pip install cryptography\n")
    ruta = os.path.join(DATOS, "secreto.key")
    if not os.path.exists(ruta):
        with open(ruta, "w") as f:
            f.write(secrets.token_hex(32))
        with contextlib.suppress(OSError):
            os.chmod(ruta, 0o600)


def secreto():
    return open(os.path.join(DATOS, "secreto.key")).read().strip().encode()


# ------------------------------------------------------------------ panel (admin)
def estado(c, yo):
    nombres = {r["id"]: r["nombre"] for r in c.execute("SELECT id,nombre FROM instancias")}
    inst = [{"id": r["id"], "n": r["nombre"], "v": r["version"] or "—", "mc": r["mc"], "e": r["estado"], "f": fmt(r["fecha"]) if r["fecha"] else "—",
             "nt": r["notas"] or r["descripcion"], "m": r["mensaje"] or "", "d": r["descripcion"] or "", "j": c.execute("SELECT COUNT(*) FROM permisos p JOIN usuarios u ON u.nombre=p.usuario WHERE p.instancia=? AND u.estado='Activo'", (r["id"],)).fetchone()[0]}
            for r in c.execute("SELECT * FROM instancias ORDER BY rowid")]
    cod = [{"c": r["codigo"], "i": [nombres.get(i, i) for i in json.loads(r["instancias"])], "ex": r["expira"], "u": r["usos"], "m": r["max_usos"], "r": r["revocado"]}
           for r in c.execute("SELECT * FROM codigos ORDER BY creado DESC")]
    us = [{"n": r["nombre"], "f": fmt(datetime.fromtimestamp(r["creado"]).strftime("%Y-%m-%d")), "e": r["estado"],
           "i": [nombres.get(p["instancia"], p["instancia"]) for p in c.execute("SELECT instancia FROM permisos WHERE usuario=?", (r["nombre"],))]}
          for r in c.execute("SELECT * FROM usuarios ORDER BY creado DESC LIMIT 500")]
    e = c.execute("SELECT * FROM eventos ORDER BY id LIMIT 1").fetchone()
    n = c.execute("SELECT COUNT(*) FROM cola WHERE evento=?", (e["id"],)).fetchone()[0]
    ev = {"n": e["nombre"], "cap": e["capacidad"], "listos": min(n, e["capacidad"]), "cola": max(n - e["capacidad"], 0), "abierto": bool(e["abierto"])}
    au = [[datetime.fromtimestamp(r["momento"]).strftime("%d/%m %H:%M"), r["quien"], r["accion"]]
          for r in c.execute("SELECT * FROM auditoria ORDER BY id DESC LIMIT 200")]
    return {"yo": yo, "inst": inst, "cod": cod, "us": us, "ev": ev, "au": au}


def siguiente_version(id_):
    carpeta = os.path.join(DATOS, "publicado", id_, "versiones")
    vs = [tuple(int(x) for x in v.split(".")) for v in (os.listdir(carpeta) if os.path.isdir(carpeta) else []) if re.match(r"^\d+\.\d+\.\d+$", v)]
    if not vs:
        return "1.0.0"
    a, b, cc = max(vs)
    return f"{a}.{b}.{cc + 1}"


def ejecutar_pub(funcion, args):
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            funcion(args)
    except SystemExit as e:
        raise ErrorApi(400, (buf.getvalue() + (str(e.code) if isinstance(e.code, str) else "")).strip() or "La publicación falló.")


def a_instancias(c, b, a):
    nombre = str(b.get("nombre", "")).strip()[:60]
    if not nombre:
        raise ErrorApi(400, "Pon un nombre al proyecto.")
    id_ = re.sub(r"[^a-z0-9]+", "_", nombre.lower()).strip("_")[:40] or "proyecto"
    if c.execute("SELECT 1 FROM instancias WHERE id=?", (id_,)).fetchone():
        raise ErrorApi(400, "Ya existe una instancia con ese nombre.")
    c.execute("INSERT INTO instancias(id,nombre,mc,estado,descripcion) VALUES(?,?,?,?,?)",
              (id_, nombre, str(b.get("mc", "Forge 1.20.1"))[:30], "oculto", str(b.get("descripcion", ""))[:200]))
    os.makedirs(os.path.join(DATOS, "contenido", id_), exist_ok=True)
    audit(c, a["usuario"], f"Creó la instancia {nombre}")
    return {"id": id_}


def a_publicar(c, b, a):
    r = c.execute("SELECT * FROM instancias WHERE id=?", (str(b.get("id", "")),)).fetchone()
    if not r:
        raise ErrorApi(404, "Instancia no encontrada.")
    version = siguiente_version(r["id"])
    mc = (re.search(r"\d+\.\d+(\.\d+)?", r["mc"]) or [None])[0] or "1.20.1"
    notas = str(b.get("notas", "")).strip()[:200] or "Actualización publicada desde el panel"
    ejecutar_pub(PUB.cmd_publicar, SimpleNamespace(
        id=r["id"], origen=os.path.join(DATOS, "contenido", r["id"]), salida=os.path.join(DATOS, "publicado"), version=version,
        tipo="pequeno", notas=notas, clave=os.path.join(DATOS, "claves", "privada.key"), forzar=False, minecraft=mc, loader="forge",
        gestionado=None, protegido=None, limpiar=None))
    nuevo = "disponible" if r["estado"] in ("proximamente", "actualizacion") else r["estado"]     # no pisa un mantenimiento
    c.execute("UPDATE instancias SET version=?, fecha=?, notas=?, estado=?, estado_manual=CASE WHEN estado!=? THEN 1 ELSE estado_manual END WHERE id=?",
              (version, date.today().isoformat(), notas, nuevo, nuevo, r["id"]))
    audit(c, a["usuario"], f"Publicó {r['nombre']} {version}")
    return {"version": version}


def a_revertir(c, b, a):
    r = c.execute("SELECT * FROM instancias WHERE id=?", (str(b.get("id", "")),)).fetchone()
    if not r or not r["version"]:
        raise ErrorApi(400, "Esta instancia todavía no tiene versiones publicadas.")
    ruta = os.path.join(DATOS, "publicado", r["id"], "historial.json")
    publicadas = [e["version"] for e in json.load(open(ruta, encoding="utf-8")) if e.get("accion") == "publicar"] if os.path.exists(ruta) else []
    if r["version"] not in publicadas or publicadas.index(r["version"]) == 0:
        raise ErrorApi(400, "No hay una versión anterior a la que volver.")
    anterior = publicadas[publicadas.index(r["version"]) - 1]
    ejecutar_pub(PUB.cmd_revertir, SimpleNamespace(id=r["id"], salida=os.path.join(DATOS, "publicado"), version=anterior))
    c.execute("UPDATE instancias SET version=? WHERE id=?", (anterior, r["id"]))
    audit(c, a["usuario"], f"Revirtió {r['nombre']} a la versión {anterior}")
    return {"version": anterior}


def a_estado_inst(c, b, a):
    r = c.execute("SELECT * FROM instancias WHERE id=?", (str(b.get("id", "")),)).fetchone()
    if not r:
        raise ErrorApi(404, "Instancia no encontrada.")
    est = str(b.get("estado", ""))
    if est not in ESTADOS_OK:
        raise ErrorApi(400, "Estado no válido.")
    msg = " ".join(str(b.get("mensaje", "")).split())[:140]
    c.execute("UPDATE instancias SET estado=?, mensaje=?, estado_manual=1 WHERE id=?", (est, msg, r["id"]))
    audit(c, a["usuario"], f"Cambió el estado de {r['nombre']} a {est}" + (f" («{msg}»)" if msg else ""))
    return {"estado": est}


def a_editar_inst(c, b, a):
    r = c.execute("SELECT * FROM instancias WHERE id=?", (str(b.get("id", "")),)).fetchone()
    if not r:
        raise ErrorApi(404, "Instancia no encontrada.")
    nombre = " ".join(str(b.get("nombre", r["nombre"])).split())[:60] or r["nombre"]
    desc = " ".join(str(b.get("descripcion", r["descripcion"])).split())[:200]
    mc = " ".join(str(b.get("mc", r["mc"])).split())[:30] or r["mc"]
    h = r["banner_hash"]
    if b.get("banner"):
        try:
            raw = base64.b64decode(str(b["banner"]).split(",", 1)[-1], validate=True)
        except ValueError:
            raise ErrorApi(400, "La imagen del banner no es válida.")
        if len(raw) > 450_000:
            raise ErrorApi(400, "El banner pesa demasiado (máximo 450 KB).")
        if not (raw.startswith(b"\x89PNG\r\n\x1a\n") or raw[:3] == b"\xff\xd8\xff"):
            raise ErrorApi(400, "El banner debe ser una imagen PNG o JPG.")
        os.makedirs(os.path.join(DATOS, "banners"), exist_ok=True)
        with open(os.path.join(DATOS, "banners", r["id"]), "wb") as f:
            f.write(raw)
        h = hashlib.sha256(raw).hexdigest()[:12]
    c.execute("UPDATE instancias SET nombre=?, descripcion=?, mc=?, banner_hash=? WHERE id=?", (nombre, desc, mc, h, r["id"]))
    audit(c, a["usuario"], f"Editó la instancia {nombre}" + (" (nuevo banner)" if b.get("banner") else ""))
    return {"ok": True}


def a_codigo(c, b, a):
    ids = [str(i) for i in b.get("instancias", [])]
    validos = {r["id"] for r in c.execute("SELECT id FROM instancias")}
    if not ids or any(i not in validos for i in ids):
        raise ErrorApi(400, "Elige al menos una instancia válida.")
    try:
        exp = datetime.strptime(str(b.get("expira", "")), "%Y-%m-%d").date().isoformat()
        mx = int(b.get("max", 1))
    except (ValueError, TypeError):
        raise ErrorApi(400, "Fecha o número de usos no válidos.")
    if not 1 <= mx <= 100000:
        raise ErrorApi(400, "Usos máximos entre 1 y 100000.")
    g = lambda: "".join(secrets.choice(ALFABETO) for _ in range(4))  # noqa: E731
    cod = f"OTTER-{g()}-{g()}"
    c.execute("INSERT INTO codigos(codigo,instancias,expira,max_usos,creado_por,creado) VALUES(?,?,?,?,?,?)", (cod, json.dumps(ids), exp, mx, a["usuario"], time.time()))
    audit(c, a["usuario"], f"Creó el código {cod}")
    return {"codigo": cod}


def a_revocar(c, b, a):
    n = c.execute("UPDATE codigos SET revocado=1 WHERE codigo=?", (str(b.get("codigo", "")),)).rowcount
    if not n:
        raise ErrorApi(404, "Código no encontrado.")
    audit(c, a["usuario"], f"Revocó el código {b['codigo']}")
    return {}


def a_usuario_estado(c, b, a):
    u = c.execute("SELECT * FROM usuarios WHERE nombre=?", (str(b.get("usuario", "")),)).fetchone()
    if not u:
        raise ErrorApi(404, "Usuario no encontrado.")
    nuevo = "Suspendido" if u["estado"] == "Activo" else "Activo"
    c.execute("UPDATE usuarios SET estado=? WHERE nombre=?", (nuevo, u["nombre"]))
    if nuevo == "Suspendido":
        c.execute("UPDATE tokens SET revocado=1 WHERE usuario=?", (u["nombre"],))
    audit(c, a["usuario"], f"{'Restauró' if nuevo == 'Activo' else 'Revocó'} el acceso de {u['nombre']}")
    return {"estado": nuevo}


def a_recuperar(c, b, a):
    u = str(b.get("usuario", ""))
    if not c.execute("SELECT 1 FROM usuarios WHERE nombre=?", (u,)).fetchone():
        raise ErrorApi(404, "Usuario no encontrado.")
    codigo = secrets.token_urlsafe(9)
    c.execute("INSERT INTO recuperaciones(usuario,codigo_hash,expira) VALUES(?,?,?)", (u, sha(codigo), time.time() + 1800))
    audit(c, a["usuario"], f"Inició la recuperación de la cuenta {u}")
    return {"codigo": codigo}


def a_abrir(c, b, a):
    e = c.execute("SELECT * FROM eventos ORDER BY id LIMIT 1").fetchone()
    nuevo = 0 if e["abierto"] else 1
    c.execute("UPDATE eventos SET abierto=? WHERE id=?", (nuevo, e["id"]))
    audit(c, a["usuario"], f"{'Abrió' if nuevo else 'Cerró'} el acceso a {e['nombre']}")
    return {"abierto": bool(nuevo)}


def firmar_pase(usuario, evento, minutos=5):
    exp = int(time.time()) + minutos * 60
    cuerpo = f"{usuario}|{evento}|{exp}"
    return cuerpo + "|" + hmac.new(secreto(), cuerpo.encode(), "sha256").hexdigest()


def a_saltar(c, b, a):
    e = c.execute("SELECT id FROM eventos ORDER BY id LIMIT 1").fetchone()
    audit(c, a["usuario"], "Se saltó la cola (permiso verificado en el servidor)")
    return {"pase": firmar_pase("admin:" + a["usuario"], e["id"])}


# ------------------------------------------------------------------ jugadores
def jugador(h, c):
    t = h.headers.get("Authorization", "")
    if not t.startswith("Bearer "):
        raise ErrorApi(401, "Falta la sesión del jugador.")
    r = c.execute("SELECT u.* FROM tokens t JOIN usuarios u ON u.nombre=t.usuario WHERE t.token_hash=? AND t.revocado=0 AND u.estado='Activo'", (sha(t[7:]),)).fetchone()
    if not r:
        raise ErrorApi(401, "Sesión no válida.")
    return r


def nuevo_token(c, usuario):
    t = secrets.token_urlsafe(32)
    c.execute("INSERT INTO tokens(token_hash,usuario) VALUES(?,?)", (sha(t), usuario))
    return t


def lista_instancias(c, usuario, h):
    base = CFG["url"] or f"http://{h.headers.get('Host', 'localhost')}"
    pub = open(os.path.join(DATOS, "claves", "publica.txt")).read().strip()
    return [{"id": r["id"], "nombre": r["nombre"], "descripcion": r["descripcion"], "minecraft": (re.search(r"\d+\.\d+(\.\d+)?", r["mc"]) or ["1.20.1"])[0],
             "loader": "Forge", "estado": r["estado"], "version": r["version"], "manifiesto_url": f"{base}/d/{r['id']}/manifest.json", "clave_publica": pub}
            for r in c.execute("SELECT i.* FROM instancias i JOIN permisos p ON p.instancia=i.id WHERE p.usuario=? AND i.version!=''", (usuario,))]


def j_canje(h, b, c):
    if not limitar(("canje", h.ip()), 10, 600):
        raise ErrorApi(429, "Demasiados intentos. Espera unos minutos.")
    u, clave, cod = str(b.get("usuario", "")), str(b.get("clave", "")), str(b.get("codigo", "")).strip().upper()
    if not RE_USUARIO.match(u):
        raise ErrorApi(400, "El nombre debe tener 3-16 letras, números o _.")
    ex = c.execute("SELECT * FROM usuarios WHERE nombre=?", (u,)).fetchone()
    if ex:
        if ex["estado"] != "Activo" or not ex["pw_hash"] or not hmac.compare_digest(hash_pw(clave, bytes.fromhex(ex["sal"])), ex["pw_hash"]):
            raise ErrorApi(401, "Usuario o contraseña incorrectos.")
    elif len(clave) < 8:
        raise ErrorApi(400, "La contraseña debe tener al menos 8 caracteres.")
    k = c.execute("SELECT * FROM codigos WHERE codigo=?", (cod,)).fetchone()
    ya = bool(k and c.execute("SELECT 1 FROM canjes WHERE codigo=? AND usuario=?", (cod, u)).fetchone())
    if not k or k["revocado"] or k["expira"] < date.today().isoformat() or (k["usos"] >= k["max_usos"] and not ya):
        raise ErrorApi(400, "El código no es válido o ya no está disponible.")
    if not ex:
        sal, ph = nueva_clave(clave)
        c.execute("INSERT INTO usuarios(nombre,creado,sal,pw_hash) VALUES(?,?,?,?)", (u, time.time(), sal, ph))
    if not ya:
        c.execute("INSERT INTO canjes VALUES(?,?,?)", (cod, u, time.time()))
        c.execute("UPDATE codigos SET usos=usos+1 WHERE codigo=?", (cod,))
        for i in json.loads(k["instancias"]):
            c.execute("INSERT OR IGNORE INTO permisos VALUES(?,?)", (u, i))
        audit(c, "(jugador) " + u, f"Canjeó el código {cod}")
    return {"token": nuevo_token(c, u), "instancias": lista_instancias(c, u, h)}


def j_entrar(h, b, c):
    u = str(b.get("usuario", ""))
    if not limitar(("entrar", h.ip(), u), 10, 600):
        raise ErrorApi(429, "Demasiados intentos. Espera unos minutos.")
    r = c.execute("SELECT * FROM usuarios WHERE nombre=?", (u,)).fetchone()
    ok = r and r["estado"] == "Activo" and r["pw_hash"] and hmac.compare_digest(hash_pw(str(b.get("clave", "")), bytes.fromhex(r["sal"])), r["pw_hash"])
    if not ok:
        raise ErrorApi(401, "Usuario o contraseña incorrectos.")
    return {"token": nuevo_token(c, u), "instancias": lista_instancias(c, u, h)}


def j_recuperar(h, b, c):
    u, cod, nueva = str(b.get("usuario", "")), str(b.get("codigo", "")), str(b.get("clave_nueva", ""))
    if not limitar(("recuperar", h.ip()), 10, 600):
        raise ErrorApi(429, "Demasiados intentos. Espera unos minutos.")
    if len(nueva) < 8:
        raise ErrorApi(400, "La contraseña debe tener al menos 8 caracteres.")
    r = c.execute("SELECT rowid FROM recuperaciones WHERE usuario=? AND codigo_hash=? AND usado=0 AND expira>?", (u, sha(cod), time.time())).fetchone()
    if not r:
        raise ErrorApi(400, "El código de recuperación no es válido o ha caducado.")
    sal, ph = nueva_clave(nueva)
    c.execute("UPDATE usuarios SET sal=?, pw_hash=? WHERE nombre=?", (sal, ph, u))
    c.execute("UPDATE recuperaciones SET usado=1 WHERE rowid=?", (r["rowid"],))
    c.execute("UPDATE tokens SET revocado=1 WHERE usuario=?", (u,))
    audit(c, "(jugador) " + u, "Recuperó su cuenta con un código del administrador")
    return {"ok": True}


def j_cola_entrar(h, b, c):
    u = jugador(h, c)
    e = c.execute("SELECT * FROM eventos ORDER BY id LIMIT 1").fetchone()
    c.execute("INSERT OR IGNORE INTO cola VALUES(?,?,?)", (e["id"], u["nombre"], time.time()))
    return j_cola_estado(h, b, c)


def j_cola_estado(h, b, c):
    u = jugador(h, c)
    e = c.execute("SELECT * FROM eventos ORDER BY id LIMIT 1").fetchone()
    m = c.execute("SELECT entrada FROM cola WHERE evento=? AND usuario=?", (e["id"], u["nombre"])).fetchone()
    if not m:
        return {"en_cola": False, "abierto": bool(e["abierto"])}
    pos = c.execute("SELECT COUNT(*) FROM cola WHERE evento=? AND entrada<=?", (e["id"], m["entrada"])).fetchone()[0]
    total = c.execute("SELECT COUNT(*) FROM cola WHERE evento=?", (e["id"],)).fetchone()[0]
    pase = bool(e["abierto"]) and pos <= e["capacidad"]
    return {"en_cola": True, "posicion": pos, "total": total, "capacidad": e["capacidad"], "abierto": bool(e["abierto"]),
            "pase": firmar_pase(u["nombre"], e["id"]) if pase else None}


# <<PAGINA>>
_PAGINA_B64 = (
    "eNrVXFtv40h2fvevqGHP9IjTFEXK8o0yNdG4PbOebV/Wdvdu1mtsl8iSxDZFqnmR7VEL2JcgDwmQhw2yi7wtAmywDwskmIcFgjzF"
    "/2T+QP5Czqkq3iT60rkAm8G0RZaqTp06dS7fOSxq95OXx3vnf3myT8bJxO+t7eIH8WkwshUWK73dMaNub3fCEkqcMY1ilthKmgyb"
    "2wp05s0BnTBbmXnsehpGiUKcMEhYAN2uPTcZ2y6beQ5r8huNeIGXeNRvxg71mW1qJBvXHHqJ7YQzFiHhxEt81jtOEhaRsyR1vZD8"
    "x59I353A+DiJqOPdfR/stkS3td04ucVPKwrDZO6EfhjBBGM2YZZLo6vuILxpxt53XjCyBmHksqgJLd0pdV1oaibh1GLBrBHTIWvS"
    "iNGmF8AysV0zpjdq3nEQJkk4qe0rvhLd15rNwch6ZlBjYLBusxmb1jPTNDvmAG/acLNlDtobcDNw4WbY7qyvw01yYz1jDttmeDNJ"
    "rWdb7nZnZwtuqGM9G+5srZub/AYoDAcDGAZ34ZX1rN12NjZwIi+wnq0PtttD7MciIDfswH9wc01hzMYOMwaLNdzgeexEoe83nyqC"
    "xdoX81ohLtYGoXs7n9BoBLMb3QF1rkZRmAauFVEXN3qEn6AOjR0DKJEN/pcmZHvjM9I0jc+0Z21qbhqUwCVsbBBPYf4gIZvGZ6o2"
    "o1EDpal2+aZa4j4BIQ9BySyzM71pmfoGOQCNizTljI1CRl4fKFp8Gyds0kw9LQaSzZhF3rALytMcM280hpGGMRsD8ylsW6B5wTRN"
    "tJj5zEnmnLIXjGFIIqeVd4s1nU6nc9eLpz69tUaR53bxTxOmgpaENaF7Ogliq72OqzSHUc2cNPZcNi8J6pnhGMxc70qpRqIzjI9D"
    "33OJlIGb66HV5sRh7d1pGIM5hYEVJ55zddvFfTS65fm6GbdDn9108U/T9SJYJ44S7HZHdGoBNVieH47CeWUE9b1R0PRghbHlMBQz"
    "724a09yAcCzZRpbgD9+Y5rXgYNswuj5DI27CtjrYVzc6bCJnIvGE+n4+38APnavKRk9StUJvo4ae2WYT0QmUk3HGFmsBnRGxt9XV"
    "5KzXLIs7KBTaZ2UtDsKAyZ1B9ZZbBCqdxlUh7KAA2tCwvAAnjWJomIYenyZhN0mTT2/5bJiUebXG6P7KqiGoxOaK/peH6bDK0hjf"
    "CxiNynbnshFY2cDcMrbLJlYlCn5FFY5yTN3w2uIOgMCCiEGyHjCtfj0Opblzr0HTJMxlwNcvhVWnwEvi473rFlvazhqJCiaINNfS"
    "tpXY2qwl3Vafzt12aW83Uacm1AvmuQlCE1lH6WyiEkzoTVMy0kYHV1Im4NZlk7Bi8ODxqLG9ysuzDWedmoZc8LOh4+7Q7YeUbjtT"
    "uiWJSUnIgNXmNjE2czcNW9qpDGqj+Y/b8xKZjZwM749kYSlxOpgvK3ipV1v0Qqe45CbR8HASfdSZ1/vMiE0ZTRqoUIgFNPCcINaG"
    "uQPca+BKVRUGtz9u8HqnGLymOzRy663r6TrbKUnf3BQySSCcDUqya6PuVL3ao/aZm5hWmKPaBcc3uPIAXuTDm47vTS10It3aRrE5"
    "JSvPGITbYF7rXHO1ga6DBHzJA8K436Tu108UWdUJiokydyeGS51fp532xvYCv9en848Q2zNGN7YNRy2cdWZFw2EliGwZhphfd+s4"
    "EBRZVPWOcM95smBb6cBn7jzEAJTcWvr6Rra6IETP7ofXzMUZaPT04FM1WC4yHquvIxiEfxZIj+jxdI7tlrlYq4CW/5mvq/cpYZqg"
    "0C1DzmUNQyeN5Yzipk50Ikwk13OU7RCk0bwRUeKjjGyxlqCcy+69mMun05hZ2QXHWKLfpnB1ybjsyWBCEXW5VQzDaGKl0ymLHApj"
    "V+DJNsCJZTNZitmFAzAz/a7zKsCHO6/pKpaBUapGFIskElpJErcKEodm26QoWTrK9coLcIeawsfksQmo7hQTSaHu7FTDhLmE1YRZ"
    "JJBRVKY1AcqarCKR8ApsIYEMYalje319WOnoBbxjFdKAhZsb5saqdQEntNpxvb1pOJWO15R3nKTVqd22uW6swgQnrALtwjLKotpa"
    "EdXmakBdRkogKgBISY2Bt2sNfMG7E0/qcwenkDCdXz+MjJZ9n7m+wTHdltN2zXbhBNVuJejCFSTeFT8jloXZMnirCOD3Ml6HhUXh"
    "dXVd71JIL4a3TZnYW2gsoHQsuWYsWE0HEAkbj6k5zmINvSgGjRs2k9spy+IOsjAdzaV0th8Gcrl2o7+S/sYae64LjElcgrwRYwE0"
    "ievN5kVy9Nl/Myov1jCxDUdPAuof4fU2SzJEICVBJHi3RmcbccxOe3adz25ZOL0bhdOqmzAMuvDpgC3nVZk0BKLv1CQqy2CAU9Gd"
    "VR3fXhqMy5TkN7ms154Bg4iWs/R06N0wt8tTimqRoEjwH9Pc78CduBD5dippcDYVEeCukNg6lxjucsV9S2uUg3hYq8kgsjDMJ/iL"
    "CQOJNwqIv40Tq3NeC6hHowA4FyLNLyXoFFL0zOZ5PFxKxsEglmJ+EWeQEZGcl3LuBc/FMrlhorqo5Chmhr4Wi7XdliiR7bZEPQ+r"
    "Nr21XTAI4rm2wsWh9Pi949M4thWUp9JbI7vxbEREJU/Z7ChErEBcY+3uq/DGVhD7b3bgf6TBhnFvV9jTN9Kc+CQjhdyY0Bc+2rZi"
    "KuRW3N3yu95uDL6C4B8BJ2xFlrmUlvwuHA55+RGGVroJ5IfdWtVpoUFw43iR4zPiAKvrbYU4t/AJ/MPgNtwOPd+3lTTyG89GKpIp"
    "dTc3RHdzi3ffzHqXJi317ux8TG9YmmDF4L3X896QH3aM7WXaxqO9mQ95QLy0TmApgntYR4S3+kbNwClNxgS26NDskI4xNg1+seHv"
    "NNuHG+AtjB91DH6x4TehDeUfhVesoCEbmlJRTH0zb8ItcejUVrjF810ClULNGpuEa6WtlDJ3UFqlUvgFlTWBw0wvIQNVeic0YD5x"
    "GaHLFeEpEuZ2LRQ7VQh3JuPQB19rK6/jlEZeqBD4S5vcxZUbwS6dEKyZJcBVGrMIi9ugmyWKU4VguLKVKfBzDS58aYY9cKMRQMu7"
    "f6XVWapfVGaCBAJztWZOsjLjZHmGu+9dbxTi+mdY2PQcsXrSOPy6r1YnhRZF+LkJoCFbCdIJDHGWGQDn0Uy8Cbowl3GzF7WlTOqQ"
    "+pCpkm1X4TEVziHDhUUKyZKj3j5v2G0JIkhuKjpGUU5kOd2qLWHwqgJXCbm102z4EpTNkj1RJs+CXYcHu5qiIZuAEvWP9l+R2WZO"
    "GTmEHA52p6RrNfOV2JPh1FB6eyDLKBzQwA3xCQi74TsCVwQ0FRRp5rlh9MOvfs9nA7/kzXri71rZ60JMgaXy2IE8lb5B749OsvDG"
    "6Agyb4zXtd74Ac/Xedjz/fl4J+4vUBa94/Pz/VNydv765cHxLq8e9/ovDw+ODs7OT/t7B3e/PoLOvLkiYbKL1VK+vXSGqgQfS+KF"
    "UKr0TkOfNKY0ooRvZUQgS5x4cRiruyLr5TSi0Aca4RSjdu8EAJjHEnQfuy3Zln1XPK6CrV/59iWLaYRPYWq/PQQ7XBrXEjzkatMS"
    "arKLQb8SurHeqPR++M3fkcPjl8fk5f7hMT49c2kSxug02DsELKFOjsAY7v4NtJROBh5WVMkIHKFLSeAROoS5KKHkXTpCPlhMIkZ9"
    "FutStBl24AIVwhac5FqNMJV3cf2R6IQt+LjOibxp0oMEDZOiT+3Y7rmhA54pSPT3KYtuz/hKw6gRqxqLHTuxe2dJBNw2ElWPGPeG"
    "jdbF892e8vlla6Q5dq8xV54rlvKcTqZdRVN28dpP8LKHlyO8/Fz5HC7fpyFv/xzbn63vdJXFhXMJyZPk58yez2DXqKXAopEpRYNt"
    "spTSVivae0tRtDWCWZ11MQ8s5adh5LvkeEj2fBqQUzahV0zRZhbEwrZuKNrEsZSvw2jECDQYuqlozFIQvIWBBz5T0d4BYGtrQ0sx"
    "dlqm0Wob7U1Fg2wL48bQG/GNAwbDyd0fKfgVCBgjz6XKQsPZgbdblBjpz0CIaUT51Ia+o6/fMzV1khQw8XfgEcMAZ9/s8Mk3qpMf"
    "pWwW4tbzGlcspzuDGMLIQQAuJwpCPtcPv/r7e2YCW7rxJhR3ly/TwHl4d5xgHwIL7CiVEVxZXIJYIQqBVIEYN/jm1o/bh82dn/ys"
    "o2iedVEv6ksNkgMFGW+a7eY6TJ1a6x1tghV5DbNKraD31bb5dfPnJ8b6A/S0GpmW5zCbAA1hjg2cYmWGTqffb/74J1s/FTM8SMrY"
    "aYLXBFLAKBbrgZbJpQBJIVetb+nM+/mPfwlLwg0yiw0C4fYheZiFD8lF7NhRCvZDv6aBILL+cURqhSEI71HA4tEvt7YE4c0K4bM0"
    "nrLAhdDHicshp17Y/y71xYDtezmpmxLFwmYWUtnHVg6CKLhpofMOr8AYmg/2G8bW9pYGuIBaHVOjA1DVJLSG1I/ZAqjQ1Lq4ELZG"
    "2iZABVgkChrXmg58z7n7ntTJggh7vtTywYZltGFUPwAGlL2IwUAI+Y4Eacsaxwfioom5bUHUzGc9BUNz6sYWusTHbvGxbYA9MOgV"
    "A2EpB4GHxgMOPM5xYA4N3VBVLi8XmXc7seclR2YpXyhaJU6B4MH6YHagGyFLAOw0ZcpFwi9RovCRSsx8qVUCGQzP+15qeRSD5nxA"
    "zkp4ZVO7d3JxpsPoS9u2gZkPH7J73QscP3VZ3KC5a4bwwWOBTlM9DeKxN0waFwG7Ji8h/W6oehK+CvFgiQwWeIJFm7uQHSttyLRH"
    "XgIuCnDcuHQ/DtOo/LUXpAkrGhaqxtnRksuci/1ze154bljay4Ozk+Ojg69e7YNgsIQKS6/4V+jT3zt/3X918HMBU3g/SLkvtQnF"
    "opo3wXw1hH6H/aPz/aODw4P9o/Nj3o2hJMtOFG3j9O7XPzs47B9CLzHpNfoUCKI+p3K89/qVHD5JSyJP6Mhmdu/tLj4OyvACNJJP"
    "5/vnF+zywrxcKL3sxrhcAOqAnr23GYGj/hsb7CaPjMoPv/lnsAxxh/qJEZEGjkdj/PIf/gmiRN6A3wvl4l/+7W+ITGU4LKGOw+KQ"
    "d5K6wnv99t/I6+xWEOD698Nf/xURLiAmt4Q34rcUUkbwRx7v8tt/IX1xDzETjKC7NkwDXm0hgAAb6vzThvIMIaEKyhaw6Efnh69s"
    "WKE+odNG4+IKNx2FJXMhAFC0ObOVT+dXizxH+HR+pnO4APp79SUkUoAqFC7DZJEnQG9V/V3oBQ1F4WVpFCQoEGp/eAXq/aUCg/Ls"
    "ifBTTfbn5ykBxSNBCA0sgOgfJyxDpKRRyipgVwG/3f0hAPsgmNNFKRtQ9XMl27Q39nxN7pjV4CuClFpuWl16vQ/LgTRmBLNGlOfZ"
    "PsUUNKH49ITqIocpIU4sg5FRZ7WCRLDuBc2DHsopjXWfBaNk/MW62Ubp9Lge9r4tQcyRdESx1LwS2ryXLuiUDlkDpHgNQIKfOHqk"
    "yolKk+SqRnmM+Rj6qNPZBJ7d83T2CTirCq6pmbBQfCJdokufOmu7ILMPvhVFw3ch+I4KT0Ea7Q4Zq1Vyq/mk2Ji2UlNoweS4ruS3"
    "O273eBgGdOki8MP5GKhJm8sCPG8Ma2ENQ9tQuaFQVKgSmSi8ViTvn84BvTfoRftSzTyJ8Dw1NYBJqir5AKM0gK+qbEE16yxYP4nu"
    "vodtCQEmoJw433wbkfCZzmZ6oIpNKg2fjqQkKgUOXC70F2Cixa8BYHxhGsbiM6Ui88cWVaKzaMlbILUoJVcSBIPiY66W9QG3tiAs"
    "4P6tZq/famuFv5WmXVoWpLBiXT00+EIfa2y+qiCWofQy+BVrCCVicJoMPS3jvoG7gPLaM1JYvpB81laQuA+lWIdiM4ocgQMFx9co"
    "UIO66P3nv/8NwcSDknx1uSut2fwE9Y0/LoaPCP6Nc+Z3W3CDDW9wCeLMqGgQPi6/zV1Q3nL3j34C5k1Kgbw8Xly0YL7cQ/Co4WlX"
    "fBs4I25Fy7ATVvakMnp6IPXck5s0KL6ROjqInmQwnj5xlgwm+4s84D8s7OW9Z9iZt+QdIF7REXzF8Ku8zdPflW/F6CF0eTJjQVJi"
    "LGNmRTUKxRD6Je+vZLCt0ZFs/6RakAdpAgbg9cnHaPJ+T6OZj3uU6om8fogucQvKgLohVfGeQPlU9iwZB0oXlbLqL6VxZD5DYrDH"
    "HMYqOHuS44AUiGrEB0ibUHAYIonIcpr4f8VzhHuhmwlEZisltxFmk32k09jLRkkTLztM2bRH3dSh+e3rOIzv8yhVB4EQhfsHZ8k/"
    "lOzS0Z06u3R0jw+FLtmmakRRl+3S0dlNpdHRUww2jj6ptkZffr4C/3mW0Tvdf3O81395LPfhcwtI9GwgUDsCEote/5vj8/KAun6Q"
    "DvUg+zl4k3dbPOAJliwBN3rZDnAJBVxWLK4GWa4qzCIs29sTrSJLOh4ziywbeZIxfJXGoPxTAOlBOBlEjITEcwGYyNQ8eoo5FI+C"
    "3i89CeLUIyI5/+FXv1fIjPopQ1EJvPNeXShPVH+5rlyBTwUWD+9T8BK+xYdJEYRIt2QqVf0H6C8BdGr3Uj3gqfo1i/ZojIl7nusD"
    "x9WvVAEyYdRcJDNXNqfGTwMcDxup2o1YkkZBYVJZGE3zMFq1lJRHsFwFV1PhVGdYjZDFqC9FSm+JVHyh5FTYamTDsZ5MBb5M6w03"
    "M5L7IidW5dOAPsVYyqbipNP6iJEVXrhlQC/I6SLipKCE9KkhKU7jx4mvyk0aYpbZW9AAKpPis8JFnXUuHg5aPuWmKfWA2QiR880H"
    "W6yWA+oS2z5nhL+hBKk15rhU5gkxf1SH+a3EtsvJRWHa2TmQTTxcXM2ghKMYt1f9gNAZJjQSU5L7jH1VG5kui5clRbymUhGL7/p7"
    "e/tnx6T/1cH+6fkx9No/IvtnJ/unfaWKDNeekvmwLO1h9+Y89SlfOZfHZzleKZXnhskTH2GVD5A5ydOh6mCZRD06fr+aM8mZMZ0q"
    "hq4tb93Stpmb2cPdhxEJHUSA1nI44lNhDaW92WNRVLaDPo7Ibkum8ICBx9RHDLs0yxlv5UslDX4YQl0CPdJ+FtpaXhorakBFdazO"
    "WrIAIPGfyACLExdg5DReMZaawPI1c8YFZvpJiqWq/BZMssirsmhB06KyIL16tTJQ8ef0wqxrbOeNj4T+Raku6Eb0uqHOeXmwi+XB"
    "anHwzYWs9l028Kgf+qH3NnZ7r6hdb9h4r77Xw4AHbKyzwlLe20yHLRqxROehWY6aFs3isS5MfgYNSVdwILsFOfFA5yeuG3gVs+Qs"
    "G3RKgxFrTLWpushLi/6ID8PHrqoWTllgj4EXuC2tZNzF+3gcXh+GLvUbal4jhnaRCNlXubP1bJHjXlxddpFg4y3WWkQ3Ukla0bfx"
    "sye9Iw54dlviroRihqZCwI2KKGkrm8YSauGUlIxMlrmjFh7iWaKIDpM6qu0VMpgU53ReMv7YWZ6UifHsDFZWwHBgDe/wRVaX4Zuv"
    "oAljFql1M6xX+G4bq4y7Hz6gguWTfkVR4KRxcvQNIL9vT77p4lN2iidqKZ4HDWvnGWRHjAAyMYX7iWliK96EjlhrGow0cfVuykar"
    "8aeu1CdO0Dw53VJICHjMc674o3vd8UNEYpDZAdxjfhlZP+gXxWGC/brku/cN/y5aclZvCy30GYuE9Oyh3cNnPCdROPGAkUZ4pQUh"
    "AgEwuE+GqkAAJLxC25Z2E9k44msQ3ymjAJXBbCIwTD+krl3CEN6E9ztAcUIXb1LTx7HzswkOZLYJ2/cZ3oETpgF4QJxTF0dyNrYN"
    "uJZnctp4wymMIIUCQ8fzX+wGxrVdMMvYPqTJWMe3lGBYC6YWb0i3xY0gomrXdvbNF7E2tvNvvoi7Ix1dheDdm2hIpnmtttpaA2g0"
    "x3h1rY3VLgjGAUz9EuT/+vRVQykpj6Zvb6ggc75whoVmvvIgbKBYeOW5oRzxkyHTFNASbgpaDCcR6IrKZRZHjh3p+IDBTxZczk8l"
    "BQZHI2cMaJHTQiLU7ccZqwDT1bJX4vnH415JPL0Ad3GPY8ryGGl4paM94JkgfBwP3kGDjqfaPEhJ9s9V+UBopl0kl+KRkDiUU5j/"
    "DBHxDNCvpzNITgVNTE4VZSGfBclzPNVAlJ3pEbwcsiCm70BCeAYJrK5UH26EU4zA1Ffv8X0lz2R2Vj3TRHqmagK5/063yJvQn7EJ"
    "PhmBvY35A23j/4FfqSsUPu5X+vZclAOtPM5pZUdl1asXKBGPqaAhqgjkHz5AWxeDjPiinX0Bba5oWs+b/HDUUHCCu++5/WSpM1Fe"
    "oHp2S+KQAGChiUqolSu+Vl73vWyyJTaRw2UGkZu3e/yhIT9vwEoWA+wsQBH4I2Cgxh8Cv61nMK/hc0BZGOBK6f6JmKCimaInj8lT"
    "Wcz/n0CCyqmkOkhwT7yv8FSBEAOs0/45mwlGK/6EhVdkV00CUmrZo5xWL6u5Dk5w0uDg9pNAxtqufOAxTeNxYx6Uj39VNe3R419V"
    "MwFvzw1FHKJZspN7rGQtqwfXKGGpEFyoYLmqK1rqH+Dw7/ISQH4iWwAzgIjO1SC8KblZ9D7ViCOoV/y9aBJVZLC8ewxBzAH7yHL6"
    "pYNt2UKw+Ewmd7/Dp53xPdovKAXpZMBANSFz429PSJqm8eeuvlj97X3DjyHcp7/ZzufO8ELXdZy3cpC07/sAfFA0F1wk2f5dWvwK"
    "ArV6ybf/Bk8XcW96I3TyEt0zKn9W1stsIAOaTnQ7TUIEeKd4+HvyBkfFHPW89oJkuw+p/21jW1U1WFT/q72X+19/86Nvf3x4dPKT"
    "07Pz129++rO//Hl7vbOxubW9o2gjO7B7uIRIPmYPtOBFRzI3sHv0YvAZlZxcFpqlOfZbcVrs0/moYagL/tlRF2+74tlDdlpq7mge"
    "Hj2sGrmWWnj28EXVej98MPm5xopVlo6nKS+ce2xSFO55jOLTQ2jSI9sUdGoOuikv8m5OiUz2rOveYDez8Z9tc3/ypWLqhm4oFrQV"
    "h4R/4b74tKXBtr64eWGqPECWj91Cw9BWxuGtIqJifvZPRkL8mPEAWFobf+jGmcoW5EELDMJ1SO704IXCAZV4eo4RA096RV4YQcZA"
    "faDRgIAyCS1C36d3f0RgPEsZIDFCfQBzgTcE8JmE+Shyu4QIYUDsBU4EK/kOy8mQTcYAozmLTjot+MuOBwIvkSwAO1n4RI7TmPO7"
    "xFWM6fHMo1gdImkANyhQaB6lUSgQKpgY7qKsAcsTh9jIv4iJiN3ZWUNYwNADcJsGVFRgxbswhMMInRzhO1uQGzDxWguJ03IvsTCs"
    "Q5eUIbUl812sPC9Xn0uHT/ODpWKT6yrVvDB99z0vUnP9VBY8PREVYw6NUlCIsibwup9wPvy0hiz32Z+U7/iMjXLLl7z8x6fCuiBc"
    "qKAqxVyUbwo/qFLMJcp/YjK+qWewFdAmtlXU/7KzYcXJTyxwlA6KqcuaVz5Elh8c49smSHVx4wdhgsri48lKPI02oCAr3A/A1D5L"
    "yOl+/5XNz9V212h8Gzgkr6bRqdeYaKk2UOeZu6TX1EvIkCXOuJFq8wlLxuApJtqY5+mxNefvSeHLUOfgqEFGdDpFJ4D0Wu9iPKuu"
    "/KzJXxCDL01loeG7jNbgy2/Pjo/0mB/89Ia3jYFqpYHLhgAPXQ0CBX/oBkxaSgxYpBlGHr7yiL4NlvDOni+6SXQ7fyf5i3ScCiQP"
    "EwOjTJ0vIAZE/Kc00hhUp2OYz5/jyp8/P9NvQxWlgyyC48ECggRMkAtfqck4Cq9JkQW/03l6DPkYv4fdzuhmj7LIu8WyJMELjmjU"
    "yOToSj5RwMo3++cglBZct+TpCbUrc1gIrN4oaJxpc/6mgsu9k4bH6110uFoaw0Uaa2wGn2ym0RQ+acpfeHBhXfzo620orqWdL0Rh"
    "FF+DKZdGs5w4P2oFHdRS2lsalD26tRNQOGzHN1mh3Rl7vnsUuiyGrEPHYsle9ltyZywuu6zbEEzmP/6EBySVrOwJvs3mUuNGIuST"
    "iS0zpDwLPLXna5W0T8i7PtCIloGUeVGZavB4OQDOsVCHTIN9FftycnyWb0xxTKslT6PAlrgQqjxXE0+Gl0PyKph2s/QjDJaAszbg"
    "/FiDRTUgS2VmDvchlfyxWO8TOBZaxTkuAhxwLlPUZc5FFWOJ/QdZyzORYgM/Ih15dAXAuhRy8FFyfZRnRDnLLP8fQFDPfRiD3iOA"
    "/Kz1vHRKEOHf1Ivoyq7RmxoAeL8EskiSvY2K4gBd4O5MTFxCgo9qm2S1lb9yMBctVgEMF8sbkMPDZdu9VyAlnS7eaFjW6kXtMk+y"
    "I7wVSIeLlacjK9jwv8NRfu7riRz1x2FU5SaEqA8xDqGXT8u8vVB08up+8Bjd/a4GPz55DdnBmVaGLnEJstHK4eViRWPAl1fxKAeV"
    "JUQKPr4xu/udD/iErBuYvmoISJBTAJ2hav0i+EVQ6NsLBe/x3eO7P4wANkIvPHiTYvQMqC+hawlJPqqV+cpyD1i7rIpWClS4HIhq"
    "FN6nLfHkeJmCxHrLfuUBMwdS8vlwve6CMKpvyyPgy0W7gZJFYaIop9CXQ7v8qQd1XX6y4hWMxFS8ofDsXtFYztqgeJrJPUUMk16I"
    "RP5SExezS/GE9JPBhw+DHAFkjgy+gEboF+NzUjV/p6LUmIVwBkBTTju0GwKC9U8vip70Uv3woV9p6MpnR/iQAovdjfJ0VyogDw7z"
    "wPMKid3oExbHdMRUEIXaXSugSxg4Y3ziKp/uQuPy890caeAg+WY8H8dLIsWmoiyQe/EWivgFDny5dRLOilxaAsIFYtN7dl+MLDST"
    "U0tzt+74dCZCsT8tGoVv5a2TUrBbAk3VUbaidB9gVULlG7EefNNfrUC4XKaoXBf4ywwa/piChr9vcKkPw2ifwnDP7uFw5YWn1ije"
    "Fbt1w+tAqB4IkOnQgoncPibJiloRORc48IVv9jYKuaMo65KRCoCG8HNfylDKVCp5yIKrdzVF+PCBZwBzniJxsCvcun1xKeoy4gK6"
    "80+a4ifiYf4Kd0nElYXl8FkkXfwlJvzZgqq8FXnYCTLwBF8V5seeKon37dLPR0CyiK8fgAfAQNAtBOUMhaQaq/Jy+MvJCpiQSJi4"
    "iTtDfTKkaq5evKaoy1+qwd9YCJiynFmhmOrU7x5lW1THF5ZUL7oVbSw/isSfa3DEMZpKuowus/xLJLpyv6yjCKI4rYxuTG8htw3y"
    "hl+GSEuf3uIL+E4KE6qwBRSfcqDWkend72CteAwhhonHSTK1Wi2zvYVFLd20trc2DNyiGfuO+3J+hKj8ABU0EJa7Bi6N/xwy2Gwj"
    "czRFoop/s9fVxCmi588/QYSHlXOVRw3pDPnYBcSjDcMwgO5uS762v9vivx602xK/GP5fWi9JsQ=="
)
# <<FIN PAGINA>>


def pagina_panel():
    """Devuelve (contenido, es_valida). La página del panel viene incrustada en este archivo (un solo archivo que copiar).
    Para probar una versión propia: define la variable de entorno OTTER_PAGINA con la ruta de un .html."""
    ruta = os.environ.get("OTTER_PAGINA")
    try:
        if ruta:
            with open(ruta, "rb") as f:
                datos = f.read()
        else:
            datos = zlib.decompress(base64.b64decode(_PAGINA_B64))
    except Exception:
        datos = b""
    if len(datos) < 5000 or b'id="login"' not in datos:
        aviso = (f'<!DOCTYPE html><meta charset="utf-8"><title>Otter Studio</title>'
                 f'<body style="font:16px system-ui;background:#0a0b0e;color:#ece8e3;padding:40px;max-width:720px;margin:auto">'
                 f'<h1 style="color:#f97316">La página del panel no es válida</h1>'
                 f'<p>Tamaño encontrado: <b>{len(datos)}</b> bytes. Vuelve a descargar <b>servidor_otter.py</b>.</p></body>')
        return aviso.encode(), False
    return datos, True


# ------------------------------------------------------------------ rutas
def a_estado(c, b, a):
    return estado(c, {"usuario": a["usuario"], "rol": a["rol"]})


ADMIN = {("GET", "/api/estado"): (a_estado, None), ("POST", "/api/instancias"): (a_instancias, "publicar"),
         ("POST", "/api/instancias/estado"): (a_estado_inst, "publicar"), ("POST", "/api/instancias/editar"): (a_editar_inst, "publicar"), ("POST", "/api/instancias/publicar"): (a_publicar, "publicar"), ("POST", "/api/instancias/revertir"): (a_revertir, "publicar"),
         ("POST", "/api/codigos"): (a_codigo, "codigo"), ("POST", "/api/codigos/revocar"): (a_revocar, "revocar"),
         ("POST", "/api/usuarios/estado"): (a_usuario_estado, "usuario"), ("POST", "/api/usuarios/recuperar"): (a_recuperar, "usuario"),
         ("POST", "/api/cola/abrir"): (a_abrir, "cola"), ("POST", "/api/cola/saltar"): (a_saltar, "cola")}
def j_estados(h, b, c):
    """Público y sin datos sensibles: solo el estado que la administración fijó a mano para cada proyecto."""
    if not limitar(("estados", h.ip()), 120, 600):
        raise ErrorApi(429, "Demasiadas consultas.")
    return {"estados": {r["id"]: {"estado": r["estado"], "mensaje": r["mensaje"] or ""}
                        for r in c.execute("SELECT id,estado,mensaje FROM instancias WHERE estado_manual=1")}}


def j_catalogo(h, b, c):
    """Público y mínimo: lo que el launcher necesita para dibujar las tarjetas. Nunca incluye mods, archivos ni usuarios."""
    if not limitar(("catalogo", h.ip()), 120, 600):
        raise ErrorApi(429, "Demasiadas consultas.")
    inst, ocultas = [], []
    for r in c.execute("SELECT * FROM instancias ORDER BY rowid"):
        if r["estado"] == "oculto":
            ocultas.append(r["id"])
            continue
        inst.append({"id": r["id"], "nombre": r["nombre"], "descripcion": r["descripcion"] or "",
                     "minecraft": (re.search(r"\d+\.\d+(\.\d+)?", r["mc"]) or ["1.20.1"])[0], "loader": "Forge",
                     "estado": r["estado"], "mensaje": r["mensaje"] or "", "manual": int(r["estado_manual"] or 0),
                     "banner_hash": r["banner_hash"] or "", "version": r["version"] or "",
                     "ultima_actualizacion": {"fecha": r["fecha"] or "", "texto": r["notas"] or ""}})
    return {"instancias": inst, "ocultas": ocultas}


JUGADOR = {("GET", "/api/v1/catalogo"): j_catalogo, ("GET", "/api/v1/estados"): j_estados, ("POST", "/api/v1/canje"): j_canje, ("POST", "/api/v1/entrar"): j_entrar, ("POST", "/api/v1/recuperar"): j_recuperar,
           ("POST", "/api/v1/cola/entrar"): j_cola_entrar, ("GET", "/api/v1/cola/estado"): j_cola_estado,
           ("GET", "/api/v1/instancias"): lambda h, b, c: {"instancias": lista_instancias(c, jugador(h, c)["nombre"], h)}}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "Otter"

    def log_message(self, *a):
        pass

    def ip(self):
        """IP del cliente. Con --publico el servidor está detrás de un túnel/proxy que está en este mismo equipo:
        solo entonces se confía en la cabecera con la IP real (así los límites de intentos van por persona)."""
        par = self.client_address[0]
        if par in LOCAL:
            ip = self.headers.get("CF-Connecting-IP") or self.headers.get("X-Forwarded-For", "").split(",")[-1].strip()
            if ip and len(ip) <= 45:
                return ip
        return par

    def _enviar(self, codigo, cuerpo, tipo="application/json", extra=()):
        if not isinstance(cuerpo, bytes):
            cuerpo = json.dumps(cuerpo, ensure_ascii=False).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", tipo + ("; charset=utf-8" if tipo.startswith("text") or tipo == "application/json" else ""))
        self.send_header("Content-Length", str(len(cuerpo)))
        for k, v in (("X-Content-Type-Options", "nosniff"), ("X-Frame-Options", "DENY"), ("Referrer-Policy", "no-referrer"),
                     ("Cache-Control", "no-store"), ("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'")):
            self.send_header(k, v)
        if es_https(self):
            self.send_header("Strict-Transport-Security", "max-age=31536000")
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(cuerpo)

    def _cuerpo(self, limite=65536):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limite:
            raise ErrorApi(413, "Petición demasiado grande.")
        try:
            return json.loads(self.rfile.read(n) or b"{}") if n else {}
        except ValueError:
            raise ErrorApi(400, "JSON no válido.")

    def _admin(self, c):
        m = SimpleCookie(self.headers.get("Cookie", "")).get("otter_sesion")
        if not m:
            raise ErrorApi(401, "Inicia sesión.")
        s = c.execute("SELECT * FROM sesiones WHERE token_hash=? AND revocada=0 AND expira>?", (sha(m.value), time.time())).fetchone()
        a = s and c.execute("SELECT * FROM admins WHERE usuario=? AND activo=1", (s["usuario"],)).fetchone()
        if not a:
            raise ErrorApi(401, "Sesión caducada.")
        return a

    def _login(self, b):
        ip = self.ip()
        if not limitar(("login", ip), 20, 600):
            raise ErrorApi(429, "Demasiados intentos. Espera unos minutos.")
        u, clave, cod = str(b.get("usuario", "")).strip().lower(), str(b.get("clave", "")), str(b.get("codigo", "")).strip()
        with tx() as c:
            a = c.execute("SELECT * FROM admins WHERE usuario=? AND activo=1", (u,)).fetchone()
            if a and a["bloqueado_hasta"] > time.time():
                raise ErrorApi(429, "Cuenta bloqueada temporalmente por intentos fallidos.")
            sal = bytes.fromhex(a["sal"]) if a else b"\0" * 16
            ph = hash_pw(clave, sal)                                      # mismo coste exista o no el usuario
            exige_mfa = mfa_obligatorio(self)
            ok = bool(a) and hmac.compare_digest(ph, a["pw_hash"]) and (not exige_mfa or totp_ok(a["totp"], cod))
            if not ok:
                if a:
                    f = a["fallos"] + 1
                    c.execute("UPDATE admins SET fallos=?, bloqueado_hasta=? WHERE usuario=?", (0 if f >= 5 else f, time.time() + 900 if f >= 5 else 0, u))
                audit(c, "(desconocido)", f"Intento de acceso fallido al usuario '{u[:30]}'")
                c.commit()
                raise ErrorApi(401, "Usuario, contraseña o código incorrectos." if exige_mfa else "Usuario o contraseña incorrectos.")
            c.execute("UPDATE admins SET fallos=0 WHERE usuario=?", (u,))
            t = secrets.token_urlsafe(32)
            c.execute("INSERT INTO sesiones VALUES(?,?,?,0)", (sha(t), u, time.time() + SESION_SEG))
            audit(c, u, "Inició sesión (MFA verificado)" if exige_mfa else "Inició sesión (sin MFA)")
        cookie = f"otter_sesion={t}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESION_SEG}" + ("; Secure" if es_https(self) else "")
        return 200, {"usuario": u, "rol": a["rol"]}, [("Set-Cookie", cookie)]

    def _descarga(self, ruta):
        partes = ruta.split("/", 3)                                       # ['', 'd', id, resto]
        if len(partes) < 4 or not RE_DESCARGA.match(partes[3]):
            raise ErrorApi(404, "No encontrado.")
        with tx() as c:
            u = jugador(self, c)
            if not c.execute("SELECT 1 FROM permisos WHERE usuario=? AND instancia=?", (u["nombre"], partes[2])).fetchone():
                raise ErrorApi(403, "No tienes acceso a esta instancia.")
        arch = os.path.join(DATOS, "publicado", partes[2], *partes[3].split("/"))
        if not os.path.isfile(arch):
            raise ErrorApi(404, "No encontrado.")
        tam = os.path.getsize(arch)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(tam))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        with open(arch, "rb") as f:
            while True:
                bloque = f.read(1 << 18)
                if not bloque:
                    break
                self.wfile.write(bloque)

    def _atender(self):
        ruta = urllib.parse.urlparse(self.path).path
        try:
            if self.command == "GET" and ruta in ("/", "/index.html"):
                contenido, valida = pagina_panel()
                return self._enviar(200 if valida else 500, contenido, "text/html")
            if ruta.startswith("/d/") and self.command == "GET":
                return self._descarga(ruta)
            if self.command == "GET" and ruta == "/version":
                contenido, _ = pagina_panel()
                return self._enviar(200, f"Otter Studio servidor v6 - pagina incrustada ({len(contenido)} bytes)\n".encode(), "text/plain")
            mb = re.match(r"^/api/v1/banner/([a-z0-9_-]{1,64})$", ruta)
            if mb and self.command == "GET":
                if not limitar(("banner", self.ip()), 300, 600):
                    raise ErrorApi(429, "Demasiadas consultas.")
                arch = os.path.join(DATOS, "banners", mb.group(1))
                if not os.path.isfile(arch):
                    raise ErrorApi(404, "No encontrado.")
                raw = open(arch, "rb").read()
                return self._enviar(200, raw, "image/png" if raw.startswith(b"\x89PNG") else "image/jpeg",
                                    extra=[("Cache-Control", "public, max-age=300")])
            if ruta == "/favicon.ico":
                return self._enviar(204, b"")
            clave = (self.command, ruta)
            if clave in JUGADOR:
                b = self._cuerpo() if self.command == "POST" else {}
                with tx() as c:
                    res = JUGADOR[clave](self, b, c)
                return self._enviar(200, res)
            if ruta.startswith("/api/"):
                if self.command == "POST":
                    if self.headers.get("X-Otter") != "1":
                        raise ErrorApi(403, "Petición no permitida.")
                    org = self.headers.get("Origin")
                    permitidos = {self.headers.get("Host")} | ({self.headers.get("X-Forwarded-Host")} if tras_proxy(self) else set())
                    if org and urllib.parse.urlparse(org).netloc not in permitidos:
                        raise ErrorApi(403, "Origen no permitido.")
                if clave == ("GET", "/api/config"):
                    return self._enviar(200, {"mfa": mfa_obligatorio(self)})
                if clave == ("POST", "/api/login"):
                    codigo, datos, extra = self._login(self._cuerpo())
                    return self._enviar(codigo, datos, extra=extra)
                if clave == ("POST", "/api/logout"):
                    with tx() as c:
                        a = self._admin(c)
                        c.execute("UPDATE sesiones SET revocada=1 WHERE usuario=?", (a["usuario"],))
                        audit(c, a["usuario"], "Cerró sesión")
                    return self._enviar(200, {}, extra=[("Set-Cookie", "otter_sesion=; Max-Age=0; Path=/")])
                if clave in ADMIN:
                    funcion, permiso = ADMIN[clave]
                    b = self._cuerpo(700_000 if ruta == "/api/instancias/editar" else 65536) if self.command == "POST" else {}
                    with tx() as c:
                        a = self._admin(c)
                        p = ROLES.get(a["rol"], set())
                        if permiso and p != "*" and permiso not in p:
                            audit(c, a["usuario"], f"Acción denegada por permisos: {ruta}")
                            c.commit()
                            raise ErrorApi(403, "Tu rol no tiene permiso para esta acción.")
                        res = funcion(c, b, a)
                    return self._enviar(200, res)
            raise ErrorApi(404, "No encontrado.")
        except ErrorApi as e:
            self._enviar(e.codigo, {"error": e.mensaje})
        except Exception as e:                                           # nunca se muestran detalles internos
            sys.stderr.write(f"Error interno: {e!r}\n")
            self._enviar(500, {"error": "Error interno del servidor."})

    do_GET = do_POST = do_HEAD = _atender


def comprobar_publico():
    """Con --publico el panel queda accesible desde Internet (por túnel o proxy): exige el MFA."""
    if not cfg()["mfa"]:
        sys.exit("\nPara compartir el panel por Internet el MFA tiene que estar ACTIVADO (si no, solo la contraseña protege el acceso).\n"
                 "Actívalo con:  python servidor_otter.py seguridad --mfa si     (o activar_mfa.bat) y vuelve a intentarlo.\n")
    with tx() as c:
        if not c.execute("SELECT 1 FROM admins WHERE activo=1").fetchone():
            sys.exit("\nTodavía no hay administradores. Crea el tuyo primero con configurar_admins.bat.\n")


# ------------------------------------------------------------------ administradores y MFA
def crear_admin(usuario, rol, clave):
    u = usuario.strip().lower()
    if not re.match(r"^[a-z0-9_.-]{3,32}$", u):
        raise ValueError("El usuario debe tener 3-32 caracteres (letras, números, _ . -).")
    if rol not in ROLES:
        raise ValueError("Rol no válido.")
    if len(clave) < 12:
        raise ValueError("La contraseña debe tener al menos 12 caracteres.")
    sec = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
    sal, ph = nueva_clave(clave)
    with tx() as d:
        d.execute("INSERT OR REPLACE INTO admins(usuario,rol,sal,pw_hash,totp) VALUES(?,?,?,?,?)", (u, rol, sal, ph, sec))
        audit(d, "(consola)", f"Creó el administrador {u} ({rol})")
    return u, sec


def mostrar_mfa(u, sec):
    grupos = " ".join(sec[i:i + 4] for i in range(0, len(sec), 4))
    print(f"\n  Administrador: {u}\n  Clave MFA (entrégasela SOLO a esa persona, por un canal privado):\n\n      {grupos}\n")
    print("  En la app (Google Authenticator / Aegis / Microsoft Authenticator): «+» → «Introducir clave de configuración»,\n"
          "  pon cualquier nombre, pega la clave y elige «basada en tiempo».\n"
          f"  Enlace alternativo: otpauth://totp/OtterStudio:{u}?secret={sec}&issuer=OtterStudio")
    print(f"  Código válido ahora mismo: {totp(sec)}  (cambia cada 30 s)\n")


def pedir_clave():
    while True:
        a = getpass.getpass("  Contraseña (mínimo 12 caracteres): ")
        if len(a) < 12:
            print("  Es demasiado corta."); continue
        if a != getpass.getpass("  Repítela: "):
            print("  No coinciden."); continue
        return a


def asistente():
    print("\n=== Crear administradores de Otter Studio ===")
    nombres = list(ROLES)
    while True:
        usuario = input("\nNombre de usuario del administrador: ").strip()
        for i, r in enumerate(nombres, 1):
            print(f"  {i}) {r}")
        try:
            rol = nombres[int(input("Rol (número): ")) - 1]
            u, sec = crear_admin(usuario, rol, pedir_clave())
        except (ValueError, IndexError) as e:
            print("  ✗", e)
            continue
        mostrar_mfa(u, sec)
        if input("¿Añadir otro administrador? (s/n): ").strip().lower() != "s":
            break
    print("\nListo. Arranca el panel con:  python servidor_otter.py ejecutar   y entra en http://127.0.0.1:8750")


# ------------------------------------------------------------------ línea de órdenes
def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    s = p.add_subparsers(dest="cmd", required=True)
    c = s.add_parser("crear-admin"); c.add_argument("--usuario", required=True); c.add_argument("--rol", choices=list(ROLES), default="Administrador")
    c = s.add_parser("ejecutar"); c.add_argument("--host", default="127.0.0.1"); c.add_argument("--puerto", type=int, default=8750)
    c.add_argument("--https", action="store_true"); c.add_argument("--url-publica", default="")
    c.add_argument("--publico", action="store_true", help="el servidor se comparte por Internet (túnel o proxy); activa HTTPS seguro y exige MFA")
    c = s.add_parser("cerrar-sesiones"); c.add_argument("--usuario", required=True)
    s.add_parser("asistente")
    c = s.add_parser("seguridad"); c.add_argument("--mfa", choices=["si", "no"], required=True)
    c = s.add_parser("mfa"); c.add_argument("--usuario", required=True)
    a = p.parse_args()
    iniciar()
    if a.cmd == "asistente":
        asistente()
    elif a.cmd == "seguridad":
        if a.mfa == "no":
            print("\nVas a QUITAR la verificación MFA: entrar al panel solo pedirá usuario y contraseña.\n"
                  "Es razonable mientras el servidor esté solo en tu PC. Si lo abres a Internet, vuelve a activarla.")
            if input("Escribe QUITAR para confirmar: ").strip() != "QUITAR":
                sys.exit("No se ha cambiado nada.")
        cfg_guardar(a.mfa == "si")
        with tx() as d:
            audit(d, "(consola)", "Activó el MFA" if a.mfa == "si" else "Desactivó el MFA")
        print("MFA " + ("ACTIVADO." if a.mfa == "si" else "DESACTIVADO. Reinicia nada: el cambio ya vale."))
    elif a.cmd == "mfa":
        with tx() as d:
            r = d.execute("SELECT usuario,totp FROM admins WHERE usuario=?", (a.usuario.strip().lower(),)).fetchone()
        if not r:
            sys.exit("Ese administrador no existe.")
        mostrar_mfa(r["usuario"], r["totp"])
    elif a.cmd == "crear-admin":
        try:
            u, sec = crear_admin(a.usuario, a.rol, pedir_clave())
        except ValueError as e:
            sys.exit(str(e))
        mostrar_mfa(u, sec)
    elif a.cmd == "cerrar-sesiones":
        with tx() as d:
            d.execute("UPDATE sesiones SET revocada=1 WHERE usuario=?", (a.usuario.lower(),))
            audit(d, "(consola)", f"Revocó todas las sesiones de {a.usuario}")
        print("Sesiones revocadas.")
    else:
        CFG.update(https=a.https or a.publico, url=a.url_publica.rstrip("/"), publico=a.publico)
        if a.publico:
            comprobar_publico()
        if not cfg()["mfa"] and a.host not in ("127.0.0.1", "localhost", "::1"):
            sys.exit("\nCon el MFA desactivado el panel solo puede abrirse en tu propio equipo (127.0.0.1).\n"
                     "Para abrirlo a Internet activa antes el MFA:  python servidor_otter.py seguridad --mfa si\n")
        try:
            srv = ThreadingHTTPServer((a.host, a.puerto), H)
        except OSError as e:
            sys.exit(f"\nNo se pudo abrir el puerto {a.puerto}: {e}\n"
                     "Puede que ya haya otro servidor de Otter abierto (cierra esa otra ventana negra) o que el puerto esté ocupado.\n"
                     f"Prueba con otro:  python servidor_otter.py ejecutar --puerto {a.puerto + 1}\n")
        srv.daemon_threads = True
        contenido, valida = pagina_panel()
        if not cfg()["mfa"]:
            print("  (MFA desactivado: el acceso solo pide usuario y contraseña)")
        print(f"Panel v6 · página incrustada ({len(contenido)} bytes)" if valida else "\n  *** AVISO: la página del panel no es válida. Descarga de nuevo servidor_otter.py ***\n")
        print(f"Otter Studio escuchando en http://{a.host}:{a.puerto}  (Ctrl+C para parar)")
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()